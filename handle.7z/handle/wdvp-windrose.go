package handle

import (
	"fmt"
	"github.com/gorilla/mux"
	"net/http"
	"strconv"
	"time"

	"github.com/woodycarl/wind-go/wind"
)

type WindRoseData struct {
	Dir  string
	Data []float64
	Sum  float64
}
type WindRose struct {
	Title   string
	Channel string
	Height  int
	Cats    []string
	Data    []WindRoseData
	Sums    []float64
}

func handleWdvpWindRose(w http.ResponseWriter, r *http.Request) {
	id := mux.Vars(r)["id"]

	data := getData(id)
	s := data.Station

	catsD := []string{"N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"}

	wdvpArg := wind.WdvpArg{
		NAngles:   16,
		IntervalV: 3,
		IntervalP: 500,
	}

	formatWindRoseData := func(wdvpFs wind.WdvpFs) (WindRose, WindRose) {
		println(fmt.Sprint(wdvpFs))
		var dataVs, dataPs []WindRoseData

		for i, v := range catsD {
			//is := strconv.Itoa(i)
			wdvpData := wdvpFs.Wdvpfs[i]
			var dataV, dataP []float64
			for j := 0; j < len(wdvpFs.AyV)-1; j++ {
				//js := strconv.Itoa(j)
				dataV = append(dataV, wdvpData.V[j]*100.0)
			}
			for j := 0; j < len(wdvpFs.AyP)-1; j++ {
				//js := strconv.Itoa(j)
				dataP = append(dataP, wdvpData.P[j]*100.0)
			}
			windRoseDataV := WindRoseData{
				Dir:  v,
				Data: dataV,
				Sum:  wdvpData.Vf * 100.0,
			}
			dataVs = append(dataVs, windRoseDataV)
			windRoseDataP := WindRoseData{
				Dir:  v,
				Data: dataP,
				Sum:  wdvpData.Pf * 100.0,
			}
			dataPs = append(dataPs, windRoseDataP)
		}

		var sumsV, sumsP []float64
		for i := 0; i < len(wdvpFs.AyV)-1; i++ {
			var sums float64
			for _, v1 := range dataVs {
				for j, v2 := range v1.Data {
					if j == i {
						sums = sums + v2
					}
				}
			}
			sumsV = append(sumsV, sums)
		}
		for i := 0; i < len(wdvpFs.AyP)-1; i++ {
			var sums float64
			for _, v1 := range dataPs {
				for j, v2 := range v1.Data {
					if j == i {
						sums = sums + v2
					}
				}
			}
			sumsP = append(sumsP, sums)
		}

		var catsV []string
		for i := 0; i < len(wdvpFs.AyV)-1; i++ {
			catsV = append(catsV, fmt.Sprint(wdvpFs.AyV[i])+"-"+fmt.Sprint(wdvpFs.AyV[i+1])+"m/s")
		}
		var catsP []string
		for i := 0; i < len(wdvpFs.AyP)-1; i++ {
			catsP = append(catsP, fmt.Sprint(wdvpFs.AyP[i])+"-"+fmt.Sprint(wdvpFs.AyP[i+1])+"W/m2")
		}

		windRoseV := WindRose{
			Cats: catsV,
			Data: dataVs,
			Sums: sumsV,
		}
		windRoseP := WindRose{
			Cats: catsP,
			Data: dataPs,
			Sums: sumsP,
		}
		return windRoseV, windRoseP
	}

	var windrose []WindRose

	windroseV, windroseP := formatWindRoseData(wind.WdvpWindRose(s.DataWd, s.DataWv, s.DataWp, wdvpArg))
	windroseV.Title = "代表年的全年风向频率分布玫瑰图"
	windroseP.Title = "代表年的全年风能频率分布玫瑰图"
	windrose = append(windrose, windroseV)
	windrose = append(windrose, windroseP)

	var wrdatas []wind.Data
	for i, _ := range s.DataTime {
		t := time.Unix(int64(s.DataTime[i]), 0)
		d := wind.Data{
			"Month": float64(int(t.Month())),
			"Wd":    s.DataWd[i],
			"Wv":    s.DataWv[i],
			"Wp":    s.DataWp[i],
		}
		wrdatas = append(wrdatas, d)
	}

	db := wind.DB(wrdatas)
	for i := 1; i < 13; i++ {
		dbM := db.Filter("Month", float64(i))
		ds := dbM.Get("Wd Wv Wp")
		wd, wv, wp := ds["Wd"], ds["Wv"], ds["Wp"]
		println(len(wd), len(wv), len(wp))

		windroseV, windroseP := formatWindRoseData(wind.WdvpWindRose(wd, wv, wp, wdvpArg))
		windroseV.Title = strconv.Itoa(i) + "月风向频率分布玫瑰图"
		windroseP.Title = strconv.Itoa(i) + "月风能频率分布玫瑰图"
		windrose = append(windrose, windroseV)
		windrose = append(windrose, windroseP)
	}

	page := Page{
		"id":   id,
		"wvps": windrose,
		"s":    s,
	}

	page.render("wvp-windrose", w)
}
